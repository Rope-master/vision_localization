var searchData=
[
  ['basic_5ftype_2ehpp',['basic_type.hpp',['../basic__type_8hpp.html',1,'']]]
];
