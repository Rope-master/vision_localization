var searchData=
[
  ['detector',['Detector',['../class_detector.html',1,'']]]
];
