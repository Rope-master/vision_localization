var searchData=
[
  ['gradient',['GRADIENT',['../lane__detector_8hpp.html#add21ba3409ea20e55aac68983f0f73ce',1,'lane_detector.hpp']]],
  ['gradient_5foperator',['GRADIENT_OPERATOR',['../lane__detector_8hpp.html#a020773e8963e80add3843ee0dd17bd6c',1,'lane_detector.hpp']]],
  ['grayscale',['GRAYSCALE',['../lane__detector_8hpp.html#a4b31056871d5bc746fb659d963a0c4d8',1,'lane_detector.hpp']]]
];
