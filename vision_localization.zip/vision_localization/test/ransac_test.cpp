#include <gtest/gtest.h>

TEST(TestRansac, testCase1)
{
}
