var dir_0c927faa06c7f1092192b98b6122d10a =
[
    [ "basic_type.hpp", "basic__type_8hpp.html", "basic__type_8hpp" ],
    [ "ipm.hpp", "ipm_8hpp.html", [
      [ "IpmTF", "class_ipm_t_f.html", "class_ipm_t_f" ]
    ] ],
    [ "ransac.hpp", "ransac_8hpp.html", [
      [ "Ransac", "class_ransac.html", "class_ransac" ]
    ] ]
];