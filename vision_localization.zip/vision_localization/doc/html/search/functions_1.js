var searchData=
[
  ['binarize',['Binarize',['../class_detector.html#a64e86d6a681c5588cc74af722463064d',1,'Detector']]]
];
