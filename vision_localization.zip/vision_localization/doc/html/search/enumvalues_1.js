var searchData=
[
  ['tracking',['TRACKING',['../basic__type_8hpp.html#ae59c9ba71c62351439e33cb4baf2df37a5b83dded44924a6ef0fc0c08bac2c232',1,'basic_type.hpp']]]
];
