var searchData=
[
  ['xytortheta',['xyToRtheta',['../class_ransac.html#a8e0261728404126d4e7c1071d90887ab',1,'Ransac::xyToRtheta(const cv::Point2d &amp;start_pt, const cv::Point2d &amp;end_pt, const cv::Point2d &amp;refer_center_pt, cv::Point2d &amp;rtheta)'],['../class_ransac.html#aa3f4f6c815b1ba5288deef130b18f747',1,'Ransac::xyToRtheta(const cv::Point2d &amp;start_pt, const cv::Point2d &amp;end_pt, const cv::Point2d &amp;refer_center_pt, double &amp;radium, double &amp;theta)']]]
];
