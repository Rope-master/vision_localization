var searchData=
[
  ['detection',['DETECTION',['../basic__type_8hpp.html#ae59c9ba71c62351439e33cb4baf2df37a167a7ee1aabe9f27e010fff93c0ba971',1,'basic_type.hpp']]]
];
