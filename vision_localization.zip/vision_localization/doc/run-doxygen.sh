#!/bin/bash

doxygen Doxyfile
